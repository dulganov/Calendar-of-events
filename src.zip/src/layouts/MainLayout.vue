<template>
  <q-drawer v-model="drawer" show-if-above bordered>
    <q-list padding>
      <q-item clickable @click="showCalendar = true">
        <q-item-section>Календарь</q-item-section>
      </q-item>
      <q-item clickable @click="showAddEvent = true">
        <q-item-section>Добавить событие</q-item-section>
      </q-item>
    </q-list>

    <q-dialog v-model="showCalendar">
      <AppCalendar @day-clicked="onDayClicked"/>
    </q-dialog>

    <EventModal :date="selectedDate" v-model:modelValue="showAddEvent" @saved="onEventSaved"/>
  </q-drawer>
</template>

<script setup>
import { ref } from 'vue'
import AppCalendar from '../components/AppCalendar.vue'
import EventModal from '../components/EventModal.vue'

const drawer = ref(true)
const showCalendar = ref(false)
const showAddEvent = ref(false)
const selectedDate = ref('')

function onDayClicked(date) {
  selectedDate.value = date
  showAddEvent.value = true
  showCalendar.value = false
}

function onEventSaved(event) {
  console.log('Событие сохранено:', event)
  
}
</script>
