<template>
  <q-layout view="lHh Lpr lFf">

    <!-- Верхняя панель -->
    <q-header elevated>
      <q-toolbar>
        <q-btn flat dense round icon="menu" aria-label="Menu" @click="leftDrawerOpen = !leftDrawerOpen" />
        <q-toolbar-title>Мой календарь</q-toolbar-title>
      </q-toolbar>
    </q-header>

    <!-- Боковая навигация -->
    <AppSidebar v-model:left-drawer="leftDrawerOpen" @day-selected="onDaySelected" />

    <!-- Основной контент -->
    <q-page-container>
      <router-view />
    </q-page-container>

    <!-- Модальное окно добавления события -->
    <EventModal
      v-model:visible="showAddEvent"
      :date="selectedDate"
      @saved="fetchEvents"
    />
  </q-layout>
</template>

<script setup>
import { ref } from 'vue'
import AppSidebar from './components/AppSidebar.vue'
import EventModal from './components/EventModal.vue'


const leftDrawerOpen = ref(true)
const showAddEvent = ref(false)
const selectedDate = ref(null)

// Обработчик выбора дня в календаре
function onDaySelected(day) {
  selectedDate.value = day
  showAddEvent.value = true
}

// Заглушка функции обновления календаря после добавления события
function fetchEvents() {
  // Можно вызвать emit для календаря или обновить данные через API
}
</script>
