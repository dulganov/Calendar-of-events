<template>
  <q-card flat bordered class="calendar-card">
    <q-card-section class="q-pa-none">
      <table class="calendar-table">
        <thead>
          <tr>
            <th v-for="day in weekdays" :key="day">{{ day }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(week, i) in calendar" :key="i">
            <td v-for="day in week" :key="day.date"
                @click="selectDay(day)"
                :class="{
                  'today': isToday(day.date),
                  'has-event': dayHasEvent(day.date),
                  'empty': !day.date
                }">
              <div class="day-number">{{ day.day }}</div>
              <div v-for="event in dayEvents(day.date)" :key="event.id" class="event-badge">
                {{ event.title }}
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </q-card-section>
  </q-card>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const emit = defineEmits(['day-clicked'])

const events = ref([])
const today = new Date()

const weekdays = ['Пн','Вт','Ср','Чт','Пт','Сб','Вс']
const year = today.getFullYear()
const month = today.getMonth()

const calendar = ref([])

onMounted(async () => {
  await fetchEvents()
  generateCalendar(year, month)
})

async function fetchEvents() {
  try {
    const res = await axios.get(`/api/events/by_month?year=${year}&month=${month+1}`)
    if (Array.isArray(res.data)) events.value = res.data
  } catch (err) {
    console.error('Ошибка загрузки событий:', err)
  }
}

function generateCalendar(y, m) {
  const firstDay = new Date(y, m, 1)
  const lastDay = new Date(y, m + 1, 0)
  const startDay = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1
  const totalDays = lastDay.getDate()

  const weeks = []
  let week = Array(startDay).fill({ day: '', date: null })

  for (let d = 1; d <= totalDays; d++) {
    const date = new Date(y, m, d)
    week.push({ day: d, date: date.toISOString().slice(0,10) })
    if (week.length === 7) {
      weeks.push(week)
      week = []
    }
  }
  if (week.length > 0) {
    while (week.length < 7) week.push({ day: '', date: null })
    weeks.push(week)
  }

  calendar.value = weeks
}

function selectDay(day) {
  if (!day.date) return
  emit('day-clicked', day.date)
}

function isToday(dateStr) {
  return dateStr === today.toISOString().slice(0,10)
}

function dayHasEvent(dateStr) {
  return events.value.some(e => e.date === dateStr)
}

function dayEvents(dateStr) {
  return events.value.filter(e => e.date === dateStr)
}
</script>

<style scoped>
.calendar-card {
  max-width: 700px;
  margin: auto;
}
.calendar-table {
  width: 100%;
  border-collapse: collapse;
}
.calendar-table th, .calendar-table td {
  text-align: center;
  border: 1px solid #eee;
  vertical-align: top;
  padding: 5px;
  min-height: 80px;
  cursor: pointer;
  position: relative;
  transition: background 0.2s;
}
.calendar-table td.empty {
  background: #f9f9f9;
  cursor: default;
}
.calendar-table td.today {
  background: #e0f7fa;
}
.event-badge {
  background: #007bff;
  color: white;
  font-size: 12px;
  padding: 2px 4px;
  border-radius: 4px;
  margin-top: 2px;
  display: inline-block;
}
</style>
