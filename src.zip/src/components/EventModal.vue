<template>
  <q-dialog v-model="visible">
    <q-card style="min-width: 350px;">
      <q-card-section>
        <div class="text-h6">Создать событие</div>

        <!-- Дата события (можно менять) -->
        <div class="q-mt-sm">
          <q-input
            dense
            readonly
            v-model="localDateDisplay"
            label="Дата"
            @click="datePicker = true"
          >
            <template #append>
              <q-icon name="event" class="cursor-pointer" @click="datePicker = true" />
            </template>
          </q-input>

          <q-popup-proxy v-model="datePicker" transition-show="scale" transition-hide="scale">
            <q-date
              v-model="localDate"
              mask="YYYY-MM-DD"
             
            />
          </q-popup-proxy>
        </div>

        <q-input v-model="title" label="Название" class="q-mt-sm"/>
        <q-input v-model="description" type="textarea" label="Описание" class="q-mt-sm"/>
      </q-card-section>

      <q-card-actions align="right">
        <q-btn label="Сохранить" color="primary" @click="saveEvent"/>
        <q-btn flat label="Отмена" v-close-popup/>
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup>
import { ref, watch, computed } from 'vue'
import { useQuasar } from 'quasar'

const props = defineProps({
  date: { type: String, default: '' },     // ожидаем формат 'YYYY-MM-DD' или ''
  modelValue: { type: Boolean, default: false }
})
const emit = defineEmits(['update:modelValue','saved'])

const visible = ref(props.modelValue)
const title = ref('')
const description = ref('')
const datePicker = ref(false)       // для q-popup-proxy
const $q = useQuasar()

// локальная дата (QDate ожидает строку формата 'YYYY/MM/DD' или 'YYYY-MM-DD' в зависимости от mask)
// будем использовать 'YYYY-MM-DD' everywhere via mask
const localDate = ref(props.date || new Date().toISOString().slice(0,10))

// удобная строка для отображения в input
const localDateDisplay = computed(() => localDate.value)

// синхронизация v-model
watch(() => props.modelValue, val => visible.value = val)
watch(visible, val => emit('update:modelValue', val))

// при смене внешней props.date обновляем локальную дату
watch(() => props.date, (val) => {
  localDate.value = val || new Date().toISOString().slice(0,10)
  // очистить поля при смене даты
  title.value = ''
  description.value = ''
})

// Сохранение события — отдаём дату, title, description
function saveEvent() {
  if (!title.value) {
    $q.notify({ message: 'Введите название', color: 'red' })
    return
  }

  // Убедимся, что дата в формате YYYY-MM-DD
  const dateOut = (localDate.value || '').replace(/\//g, '-')

  const payload = {
    title: title.value,
    description: description.value,
    date: dateOut
  }

  emit('saved', payload)      // вызываем сохранение у родителя
  visible.value = false
  $q.notify({ message: 'Событие добавлено', color: 'green' })
}
</script>
