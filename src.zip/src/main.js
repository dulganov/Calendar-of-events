import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { Quasar } from 'quasar'
import quasarUserOptions from './quasar-user-options'

// Подключаем стили VCalendar
import VCalendar from 'v-calendar'
import 'v-calendar/dist/style.css'

const app = createApp(App)

app.use(router)
app.use(Quasar, quasarUserOptions)
app.use(VCalendar, {}) // глобальная регистрация

app.mount('#app')
