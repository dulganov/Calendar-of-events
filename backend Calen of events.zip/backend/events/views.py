# events/views.py
from rest_framework import viewsets
from .models import Event
from .serializers import EventSerializer
from rest_framework.decorators import action
from rest_framework.response import Response
from datetime import date

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer

    @action(detail=False, methods=['get'])
    def by_month(self, request):
        year = int(request.query_params.get('year', date.today().year))
        month = int(request.query_params.get('month', date.today().month))
        events = Event.objects.filter(date__year=year, date__month=month)
        serializer = self.get_serializer(events, many=True)
        return Response(serializer.data)
